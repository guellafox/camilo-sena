<!-- index.html -->
<!DOCTYPE html>
<html>
<head>
    <title>Formulario de cursos</title>
</head>
<body>
    <h1>Formulario de Cursos</h1>
    <form action="enviar.php" method="post">
        nombre: <input type="text" name="codigo"><br>
        apellido: <input type="text" name="nombre"><br>
        correo electronico: <input type="text" name="documento_id"><br>
        <input type="submit" value="Guardar">
    </form>
</body>
</html>
